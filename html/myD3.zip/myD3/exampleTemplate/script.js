

console.log("Hello world!");
